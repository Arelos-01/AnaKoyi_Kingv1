#!/system/bin/sh
# policy/rules/decide_profile.sh — Anakoyi King v2.0

pick_profile() {
    wifi_state="$1"
    iface="$2"
    details="$3"
    wifi_details="$4"
    last_event="$5"

    # Si hay perfil manual forzado, respetarlo
    forced="$(getprop persist.Anakoti_king.boot_profile 2>/dev/null)"
    case "$forced" in
        extreme|diablo|gaming|speed|stable|bench_ping|bench_speed)
            echo "$forced"
            return
            ;;
    esac

    case "$wifi_state" in
        connected)
            case "$details" in
                *no_default_route*|*no_ip*) echo "stable" ;;
                *) echo "gaming" ;;
            esac
            ;;
        disconnected) echo "stable" ;;
        *) echo "stable" ;;
    esac
}
