#!/system/bin/sh
# wifi_boost.sh — Anakoyi King v2.0
# Extrae todo el internet del WiFi para el celular.
# Se aplica en TODOS los perfiles de red.

_LOG="${SERVICES_LOGS:-/dev/null}"
echo "[WIFI_BOOST] start" >> "$_LOG"

# ── Power save OFF: señal siempre al 100% ──────────────────────────────────
iw dev wlan0 set power_save off 2>/dev/null || true
iw dev wlan1 set power_save off 2>/dev/null || true

# Drivers RTW: rtw_power_mgnt=0 = power save off
for _pm in /sys/module/8821cu/parameters/rtw_power_mgnt \
           /sys/module/8188eu/parameters/rtw_power_mgnt \
           /sys/module/8821cs/parameters/rtw_power_mgnt \
           /sys/module/8852be/parameters/rtw_power_mgnt \
           /sys/module/wlan/parameters/rtw_power_mgnt; do
    [ -f "$_pm" ] && echo "0" > "$_pm" 2>/dev/null || true
done

# Qualcomm wlan power save
for _qpm in /sys/module/wlan/parameters/power_mgnt \
            /sys/kernel/debug/ieee80211/phy0/wil6210/power_save; do
    [ -f "$_qpm" ] && echo "0" > "$_qpm" 2>/dev/null || true
done

# ── WiFi settings via wlan driver sysfs ───────────────────────────────────
# Scan throttle OFF = respuesta más rápida a cambios de AP
_wlan_cfg="/data/misc/wifi/wpa_supplicant.conf"
_wlan_sysfs="/sys/module/wlan/parameters"

[ -f "$_wlan_sysfs/scan_interval" ]        && echo "5"   > "$_wlan_sysfs/scan_interval"        2>/dev/null || true
[ -f "$_wlan_sysfs/scan_passive_dwell" ]   && echo "20"  > "$_wlan_sysfs/scan_passive_dwell"   2>/dev/null || true
[ -f "$_wlan_sysfs/scan_active_dwell" ]    && echo "40"  > "$_wlan_sysfs/scan_active_dwell"    2>/dev/null || true

# ── Qualcomm WCNSS / CNSS WiFi tweaks ─────────────────────────────────────
# Beam-forming TX = más señal dirigida hacia el router
for _wini in /data/misc/wifi/WCNSS_qcom_cfg.ini \
             /vendor/etc/wifi/WCNSS_qcom_cfg.ini; do
    if [ -f "$_wini" ]; then
        # Activar beamforming, aumentar agresividad, desactivar DTIM modulado
        sed -i 's/gEnableTxSUBeamformer=.*/gEnableTxSUBeamformer=1/' "$_wini" 2>/dev/null || true
        sed -i 's/gEnableModulatedDTIM=.*/gEnableModulatedDTIM=1/' "$_wini" 2>/dev/null || true
        sed -i 's/gMaxLIModulatedDTIM=.*/gMaxLIModulatedDTIM=1/' "$_wini" 2>/dev/null || true
        sed -i 's/gTxAggregationSize=.*/gTxAggregationSize=64/' "$_wini" 2>/dev/null || true
        sed -i 's/gRxAggregationSize=.*/gRxAggregationSize=64/' "$_wini" 2>/dev/null || true
        sed -i 's/gEnableNUDTracking=.*/gEnableNUDTracking=2/' "$_wini" 2>/dev/null || true
    fi
done

# ── Aumentar buffers del driver WiFi ──────────────────────────────────────
# Socket buffer mínimo para WiFi
[ -f /proc/sys/net/core/rmem_max ] && \
    cur=$(cat /proc/sys/net/core/rmem_max 2>/dev/null) && \
    [ "${cur:-0}" -lt "16777216" ] && echo "16777216" > /proc/sys/net/core/rmem_max 2>/dev/null || true

# ── Eliminar interferencia: desactivar Bluetooth coexistencia agresiva ────
for _btcoex in /sys/module/wlan/parameters/btcoex_support \
               /proc/bluetooth/sleep/btcoex; do
    [ -f "$_btcoex" ] && echo "0" > "$_btcoex" 2>/dev/null || true
done

# ── Net core: reducir latencia de recepción ────────────────────────────────
# Menos tiempo esperando para procesar paquetes = menor latencia
echo "0" > /proc/sys/net/core/netdev_tstamp_prequeue 2>/dev/null || true
echo "1" > /proc/sys/net/ipv4/tcp_low_latency         2>/dev/null || true

echo "[WIFI_BOOST] done" >> "$_LOG"
