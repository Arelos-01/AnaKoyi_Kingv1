#!/system/bin/sh
# extreme_profile — Anakoyi King v2.0: Rendimiento Extremo
# Fluido como RedMagic 11. WiFi al máximo. Ping estable en juegos.
# CPU/Touch/IO optimizados para gaming de alto nivel.

LOG_OUT="${SERVICES_LOGS:-/dev/null}"
echo "[PROFILE] extreme start" >> "$LOG_OUT"

apply_param_set <<'EOF2'
1|/proc/sys/net/core/bpf_jit_enable|bpf_jit
0|/proc/sys/net/core/bpf_jit_harden|harden off
1|/proc/sys/net/core/bpf_jit_kallsyms|kallsyms
67108864|/proc/sys/net/core/bpf_jit_limit|64MB
50|/proc/sys/net/core/busy_poll|busy_poll 50ms
100|/proc/sys/net/core/busy_read|busy_read 100
fq_codel|/proc/sys/net/core/default_qdisc|fq_codel latencia
256|/proc/sys/net/core/dev_weight|dev_weight
2|/proc/sys/net/core/dev_weight_rx_bias|rx bias
2|/proc/sys/net/core/dev_weight_tx_bias|tx bias
512|/proc/sys/net/core/netdev_budget|budget
1200|/proc/sys/net/core/netdev_budget_usecs|budget_usecs
4096|/proc/sys/net/core/netdev_max_backlog|backlog
33554432|/proc/sys/net/core/wmem_max|32MB
33554432|/proc/sys/net/core/rmem_max|32MB
524288|/proc/sys/net/core/wmem_default|512KB
524288|/proc/sys/net/core/rmem_default|512KB
262144|/proc/sys/net/core/optmem_max|256KB
65536|/proc/sys/net/core/rps_sock_flow_entries|rps
8192|/proc/sys/net/core/somaxconn|somaxconn
1|/proc/sys/net/core/tstamp_allow_data|tstamp
EOF2

apply_param_set <<'EOF2'
0|/proc/sys/net/ipv4/tcp_ecn|ECN off
1|/proc/sys/net/ipv4/tcp_sack|SACK
1|/proc/sys/net/ipv4/tcp_fack|FACK
1|/proc/sys/net/ipv4/tcp_window_scaling|window scaling
4096 262144 33554432|/proc/sys/net/ipv4/tcp_rmem|32MB max
4096 262144 33554432|/proc/sys/net/ipv4/tcp_wmem|32MB max
8388608 16777216 33554432|/proc/sys/net/ipv4/tcp_mem|tcp_mem
1|/proc/sys/net/ipv4/tcp_no_metrics_save|no_metrics
3|/proc/sys/net/ipv4/tcp_fastopen|fastopen TFO
1|/proc/sys/net/ipv4/tcp_tw_reuse|tw_reuse
2|/proc/sys/net/ipv4/tcp_retries1|retries1
5|/proc/sys/net/ipv4/tcp_retries2|retries2
524288|/proc/sys/net/ipv4/tcp_limit_output_bytes|512KB
1|/proc/sys/net/ipv4/tcp_orphan_retries|orphan
4096|/proc/sys/net/ipv4/tcp_max_syn_backlog|syn backlog
3|/proc/sys/net/ipv4/tcp_fin_timeout|fin_timeout 3s
15|/proc/sys/net/ipv4/tcp_keepalive_time|keepalive 15s
3|/proc/sys/net/ipv4/tcp_keepalive_intvl|intvl 3s
3|/proc/sys/net/ipv4/tcp_keepalive_probes|probes
1|/proc/sys/net/ipv4/tcp_syncookies|syncookies
1|/proc/sys/net/ipv4/tcp_timestamps|timestamps
0|/proc/sys/net/ipv4/tcp_slow_start_after_idle|no slow start
1|/proc/sys/net/ipv4/tcp_low_latency|low_latency ON
1|/proc/sys/net/ipv4/tcp_mtu_probing|mtu probing
1|/proc/sys/net/ipv4/tcp_frto|frto
1|/proc/sys/net/ipv4/tcp_moderate_rcvbuf|moderate rcvbuf
1|/proc/sys/net/ipv4/tcp_early_retrans|early retrans
3|/proc/sys/net/ipv4/tcp_early_demux|early demux
1|/proc/sys/net/ipv4/udp_early_demux|udp early demux
1024 65535|/proc/sys/net/ipv4/ip_local_port_range|puertos
1|/proc/sys/net/ipv4/tcp_rfc1337|rfc1337
EOF2

# VM / IO gaming performance
apply_param_set <<'EOF2'
3|/proc/sys/vm/dirty_background_ratio|dirty bg 3%
10|/proc/sys/vm/dirty_ratio|dirty 10%
3000|/proc/sys/vm/dirty_expire_centisecs|expire 3s
500|/proc/sys/vm/dirty_writeback_centisecs|writeback fast
10|/proc/sys/vm/swappiness|swappiness muy bajo
0|/proc/sys/vm/zone_reclaim_mode|zone reclaim off
1|/proc/sys/vm/page-cluster|page cluster 1
EOF2

# CPU scheduling for gaming (try to boost responsiveness)
for cpu_gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [ -f "$cpu_gov" ] && echo "performance" > "$cpu_gov" 2>/dev/null || true
done

# Touch boost - reduce input latency
for touch in /sys/module/msm_performance/parameters/touchboost \
             /sys/power/pnpmgr/touch_boost \
             /proc/sys/kernel/sched_boost; do
    [ -f "$touch" ] && echo "1" > "$touch" 2>/dev/null || true
done

# WiFi power management OFF = señal siempre al máximo
for wifi_pm in /sys/module/8821cu/parameters/rtw_power_mgnt \
               /sys/module/8188eu/parameters/rtw_power_mgnt \
               /sys/bus/pci/drivers/ath10k_pci/*/power_mgmt \
               /sys/class/net/wlan0/power/control; do
    [ -f "$wifi_pm" ] && echo "0" > "$wifi_pm" 2>/dev/null || \
    { [ -f "$wifi_pm" ] && echo "on" > "$wifi_pm" 2>/dev/null || true; }
done
iw dev wlan0 set power_save off 2>/dev/null || true

# BBR2 > BBR > cubic
if [ -f /proc/sys/net/ipv4/tcp_available_congestion_control ]; then
    if grep -qw bbr2 /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null; then
        echo "bbr2" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
    elif grep -qw bbr /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null; then
        echo "bbr" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
    else
        echo "cubic" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
    fi
fi

# CAKE qdisc si disponible
if tc qdisc add dev lo root cake 2>/dev/null; then
    tc qdisc del dev lo root 2>/dev/null
    echo "cake" > /proc/sys/net/core/default_qdisc 2>/dev/null
fi

# IO scheduler - deadline para gaming
for io_sched in /sys/block/*/queue/scheduler; do
    [ -f "$io_sched" ] && echo "deadline" > "$io_sched" 2>/dev/null || \
    { echo "cfq" > "$io_sched" 2>/dev/null || true; }
done


# ── WiFi Boost: extrae todo el internet del WiFi ──────────────────────────
_MODDIR_WB="${NEWMODPATH:-${MODDIR:-}}"
if [ -f "$_MODDIR_WB/net_profiles/wifi_boost.sh" ]; then
    . "$_MODDIR_WB/net_profiles/wifi_boost.sh"
fi
echo "[PROFILE] extreme done" >> "$LOG_OUT"
