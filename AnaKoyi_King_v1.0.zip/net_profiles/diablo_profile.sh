#!/system/bin/sh
# diablo_profile — Anakoyi King v2.0: MODO DIABLO
# PC Gamer en el celular. Extrae TODO el internet del WiFi.
# WiFi al 100%, ping mínimo, juegos ultra fluidos, apps instantáneas.

LOG_OUT="${SERVICES_LOGS:-/dev/null}"
echo "[PROFILE] diablo start" >> "$LOG_OUT"

# ─── RED: máxima agresividad ───────────────────────────────────────────────
apply_param_set <<'EOF2'
1|/proc/sys/net/core/bpf_jit_enable|bpf_jit
0|/proc/sys/net/core/bpf_jit_harden|harden off
1|/proc/sys/net/core/bpf_jit_kallsyms|kallsyms
134217728|/proc/sys/net/core/bpf_jit_limit|128MB
100|/proc/sys/net/core/busy_poll|busy_poll 100
200|/proc/sys/net/core/busy_read|busy_read 200
fq|/proc/sys/net/core/default_qdisc|fq throughput+lat
512|/proc/sys/net/core/dev_weight|dev_weight max
4|/proc/sys/net/core/dev_weight_rx_bias|rx bias max
4|/proc/sys/net/core/dev_weight_tx_bias|tx bias max
1024|/proc/sys/net/core/netdev_budget|budget max
3000|/proc/sys/net/core/netdev_budget_usecs|budget_usecs max
16384|/proc/sys/net/core/netdev_max_backlog|backlog max
67108864|/proc/sys/net/core/wmem_max|64MB TX
67108864|/proc/sys/net/core/rmem_max|64MB RX
1048576|/proc/sys/net/core/wmem_default|1MB default
1048576|/proc/sys/net/core/rmem_default|1MB default
524288|/proc/sys/net/core/optmem_max|512KB
131072|/proc/sys/net/core/rps_sock_flow_entries|rps max
16384|/proc/sys/net/core/somaxconn|somaxconn max
1|/proc/sys/net/core/tstamp_allow_data|tstamp
EOF2

apply_param_set <<'EOF2'
0|/proc/sys/net/ipv4/tcp_ecn|ECN off
1|/proc/sys/net/ipv4/tcp_sack|SACK
1|/proc/sys/net/ipv4/tcp_fack|FACK
1|/proc/sys/net/ipv4/tcp_window_scaling|window scaling
4096 1048576 67108864|/proc/sys/net/ipv4/tcp_rmem|64MB max
4096 1048576 67108864|/proc/sys/net/ipv4/tcp_wmem|64MB max
16777216 33554432 67108864|/proc/sys/net/ipv4/tcp_mem|tcp_mem max
1|/proc/sys/net/ipv4/tcp_no_metrics_save|no_metrics
3|/proc/sys/net/ipv4/tcp_fastopen|fastopen TFO
1|/proc/sys/net/ipv4/tcp_tw_reuse|tw_reuse
1|/proc/sys/net/ipv4/tcp_retries1|retries1 ultra
3|/proc/sys/net/ipv4/tcp_retries2|retries2 ultra
1048576|/proc/sys/net/ipv4/tcp_limit_output_bytes|1MB
1|/proc/sys/net/ipv4/tcp_orphan_retries|orphan
8192|/proc/sys/net/ipv4/tcp_max_syn_backlog|syn backlog
2|/proc/sys/net/ipv4/tcp_fin_timeout|fin_timeout 2s
10|/proc/sys/net/ipv4/tcp_keepalive_time|keepalive 10s
2|/proc/sys/net/ipv4/tcp_keepalive_intvl|intvl 2s
2|/proc/sys/net/ipv4/tcp_keepalive_probes|probes
1|/proc/sys/net/ipv4/tcp_syncookies|syncookies
0|/proc/sys/net/ipv4/tcp_timestamps|timestamps off
0|/proc/sys/net/ipv4/tcp_slow_start_after_idle|no slow start
1|/proc/sys/net/ipv4/tcp_low_latency|low_latency ON
1|/proc/sys/net/ipv4/tcp_mtu_probing|mtu probing
1|/proc/sys/net/ipv4/tcp_frto|frto
1|/proc/sys/net/ipv4/tcp_moderate_rcvbuf|moderate rcvbuf
0|/proc/sys/net/ipv4/tcp_autocorking|autocork OFF lag
1|/proc/sys/net/ipv4/tcp_early_retrans|early retrans
1024 65535|/proc/sys/net/ipv4/ip_local_port_range|puertos max
1|/proc/sys/net/ipv4/tcp_rfc1337|rfc1337
67108864|/proc/sys/net/ipv4/ipfrag_high_thresh|64MB
50331648|/proc/sys/net/ipv4/ipfrag_low_thresh|48MB
EOF2

apply_param_set <<'EOF2'
67108864|/proc/sys/net/ipv6/ip6frag_high_thresh|64MB
50331648|/proc/sys/net/ipv6/ip6frag_low_thresh|48MB
EOF2

# ─── VM/IO: todo a rendimiento ─────────────────────────────────────────────
apply_param_set <<'EOF2'
1|/proc/sys/vm/dirty_background_ratio|1%
5|/proc/sys/vm/dirty_ratio|5%
1000|/proc/sys/vm/dirty_expire_centisecs|expire 1s
200|/proc/sys/vm/dirty_writeback_centisecs|writeback ultra
0|/proc/sys/vm/swappiness|swappiness 0
0|/proc/sys/vm/zone_reclaim_mode|off
0|/proc/sys/vm/page-cluster|page cluster 0
200|/proc/sys/vm/vfs_cache_pressure|cache pressure low
EOF2

# ─── CPU: performance total ────────────────────────────────────────────────
for cpu_gov in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [ -f "$cpu_gov" ] && echo "performance" > "$cpu_gov" 2>/dev/null || true
done

# Max CPU freq
for cpu_max in /sys/devices/system/cpu/cpu*/cpufreq/scaling_max_freq; do
    if [ -f "$cpu_max" ]; then
        max_f=$(cat "/sys/devices/system/cpu/${cpu_max%/cpufreq/scaling_max_freq}/cpufreq/cpuinfo_max_freq" 2>/dev/null)
        [ -n "$max_f" ] && echo "$max_f" > "$cpu_max" 2>/dev/null || true
    fi
done

# ─── Touch boost / Input responsiveness ────────────────────────────────────
for touch in /sys/module/msm_performance/parameters/touchboost \
             /sys/power/pnpmgr/touch_boost \
             /sys/class/input_booster/touchbooster/boost_on \
             /proc/sys/kernel/sched_boost; do
    [ -f "$touch" ] && echo "1" > "$touch" 2>/dev/null || true
done

# Reduce input latency
[ -f /sys/module/cpu_input_boost/parameters/input_boost_duration ] && \
    echo "200" > /sys/module/cpu_input_boost/parameters/input_boost_duration 2>/dev/null || true

# ─── WiFi: máxima señal, cero power save ───────────────────────────────────
iw dev wlan0 set power_save off 2>/dev/null || true
iw dev wlan1 set power_save off 2>/dev/null || true

for wifi_pm in /sys/module/8821cu/parameters/rtw_power_mgnt \
               /sys/module/8188eu/parameters/rtw_power_mgnt \
               /sys/module/wlan/parameters/power_mgnt; do
    [ -f "$wifi_pm" ] && echo "0" > "$wifi_pm" 2>/dev/null || true
done

# WiFi TX power max
iw dev wlan0 set txpower fixed 3000 2>/dev/null || true

# ─── IO scheduler: performance ─────────────────────────────────────────────
for io_sched in /sys/block/*/queue/scheduler; do
    [ -f "$io_sched" ] && echo "deadline" > "$io_sched" 2>/dev/null || \
    { echo "noop" > "$io_sched" 2>/dev/null || true; }
done

for io_nr in /sys/block/*/queue/nr_requests; do
    [ -f "$io_nr" ] && echo "512" > "$io_nr" 2>/dev/null || true
done

# ─── BBR2 > BBR > cubic ────────────────────────────────────────────────────
if [ -f /proc/sys/net/ipv4/tcp_available_congestion_control ]; then
    if grep -qw bbr2 /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null; then
        echo "bbr2" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
    elif grep -qw bbr /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null; then
        echo "bbr" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
    else
        echo "cubic" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
    fi
fi


# ── WiFi Boost: extrae todo el internet del WiFi ──────────────────────────
_MODDIR_WB="${NEWMODPATH:-${MODDIR:-}}"
if [ -f "$_MODDIR_WB/net_profiles/wifi_boost.sh" ]; then
    . "$_MODDIR_WB/net_profiles/wifi_boost.sh"
fi
echo "[PROFILE] diablo done" >> "$LOG_OUT"
