#!/system/bin/sh
# speed_profile — Anakoyi King: throughput máximo + BBR

LOG_OUT="${SERVICES_LOGS:-/dev/null}"
echo "[PROFILE] speed start" >> "$LOG_OUT"

apply_param_set <<'EOF2'
1|/proc/sys/net/core/bpf_jit_enable|bpf_jit
0|/proc/sys/net/core/bpf_jit_harden|off max perf
1|/proc/sys/net/core/bpf_jit_kallsyms|enabled
67108864|/proc/sys/net/core/bpf_jit_limit|64MB
0|/proc/sys/net/core/busy_poll|off
0|/proc/sys/net/core/busy_read|off
fq|/proc/sys/net/core/default_qdisc|fq throughput
384|/proc/sys/net/core/dev_weight|dev_weight alto
1024|/proc/sys/net/core/netdev_budget|budget alto
3000|/proc/sys/net/core/netdev_budget_usecs|usecs alto
8192|/proc/sys/net/core/netdev_max_backlog|backlog alto
33554432|/proc/sys/net/core/wmem_max|32MB
33554432|/proc/sys/net/core/rmem_max|32MB
524288|/proc/sys/net/core/wmem_default|512KB
524288|/proc/sys/net/core/rmem_default|512KB
524288|/proc/sys/net/core/optmem_max|512KB
8192|/proc/sys/net/core/somaxconn|somaxconn
1|/proc/sys/net/core/tstamp_allow_data|tstamp
EOF2

apply_param_set <<'EOF2'
0|/proc/sys/net/ipv4/tcp_ecn|ECN off
1|/proc/sys/net/ipv4/tcp_sack|SACK
1|/proc/sys/net/ipv4/tcp_fack|FACK
1|/proc/sys/net/ipv4/tcp_window_scaling|window scaling
4096 262144 33554432|/proc/sys/net/ipv4/tcp_rmem|32MB max
4096 262144 33554432|/proc/sys/net/ipv4/tcp_wmem|32MB max
8388608 16777216 33554432|/proc/sys/net/ipv4/tcp_mem|tcp_mem
1|/proc/sys/net/ipv4/tcp_moderate_rcvbuf|moderate rcvbuf
0|/proc/sys/net/ipv4/tcp_slow_start_after_idle|no slow start
1|/proc/sys/net/ipv4/tcp_autocorking|autocorking
1|/proc/sys/net/ipv4/tcp_no_metrics_save|no_metrics
3|/proc/sys/net/ipv4/tcp_fastopen|fastopen
1|/proc/sys/net/ipv4/tcp_timestamps|timestamps
1|/proc/sys/net/ipv4/tcp_tw_reuse|tw_reuse
0|/proc/sys/net/ipv4/tcp_mtu_probing|off overhead
1|/proc/sys/net/ipv4/tcp_rfc1337|rfc1337
512 65535|/proc/sys/net/ipv4/ip_local_port_range|puertos
33554432|/proc/sys/net/ipv4/ipfrag_high_thresh|32MB
25165824|/proc/sys/net/ipv4/ipfrag_low_thresh|24MB
4096|/proc/sys/net/ipv4/udp_rmem_min|udp
4096|/proc/sys/net/ipv4/udp_wmem_min|udp
4096 262144 33554432|/proc/sys/net/ipv4/udp_mem|32MB
EOF2

apply_param_set <<'EOF2'
33554432|/proc/sys/net/ipv6/ip6frag_high_thresh|32MB
25165824|/proc/sys/net/ipv6/ip6frag_low_thresh|24MB
EOF2

apply_param_set <<'EOF2'
5|/proc/sys/vm/dirty_background_ratio|dirt bg 5%
15|/proc/sys/vm/dirty_ratio|dirt 15%
15000|/proc/sys/vm/dirty_expire_centisecs|expire
3000|/proc/sys/vm/dirty_writeback_centisecs|writeback
40|/proc/sys/vm/swappiness|swappiness bajo
0|/proc/sys/vm/zone_reclaim_mode|zone reclaim off
EOF2

# BBR2 > BBR > cubic
if [ -f /proc/sys/net/ipv4/tcp_available_congestion_control ]; then
    if grep -qw bbr2 /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null; then
        echo "bbr2" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
        echo "[PROFILE] speed: bbr2" >> "$LOG_OUT"
    elif grep -qw bbr /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null; then
        echo "bbr" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
        echo "[PROFILE] speed: bbr" >> "$LOG_OUT"
    else
        echo "cubic" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
        echo "[PROFILE] speed: cubic" >> "$LOG_OUT"
    fi
fi


# ── WiFi Boost: extrae todo el internet del WiFi ──────────────────────────
_MODDIR_WB="${NEWMODPATH:-${MODDIR:-}}"
if [ -f "$_MODDIR_WB/net_profiles/wifi_boost.sh" ]; then
    . "$_MODDIR_WB/net_profiles/wifi_boost.sh"
fi
echo "[PROFILE] speed done" >> "$LOG_OUT"
