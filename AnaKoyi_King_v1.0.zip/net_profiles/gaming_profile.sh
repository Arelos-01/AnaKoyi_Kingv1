#!/system/bin/sh
# gaming_profile — Anakoyi King: latencia mínima + BBR dinámico

if [ -z "${NEWMODPATH:-}" ] || [ ! -d "${NEWMODPATH:-/}" ]; then
    _caller_dir="${0%/*}"
    case "$_caller_dir" in
        */net_profiles) NEWMODPATH="${_caller_dir%/net_profiles}" ;;
        *) NEWMODPATH="${_caller_dir%/*}" ;;
    esac
fi

profile_aplicated="${NEWMODPATH}/logs/profile_aplicated.log"
[ -n "${MODDIR:-}" ] && [ -d "${MODDIR:-/}" ] && profile_aplicated="${MODDIR}/logs/profile_aplicated.log"
mkdir -p "$(dirname "$profile_aplicated")" 2>/dev/null || true
echo "[PROFILE] gaming start" >> "$profile_aplicated"

apply_param_set <<'EOF2'
1|/proc/sys/net/core/bpf_jit_enable|bpf_jit enabled
0|/proc/sys/net/core/bpf_jit_harden|bpf_jit_harden off para max perf
1|/proc/sys/net/core/bpf_jit_kallsyms|bpf_jit_kallsyms enabled
16777216|/proc/sys/net/core/bpf_jit_limit|16MB
0|/proc/sys/net/core/busy_poll|busy_poll off (ahorro CPU)
50|/proc/sys/net/core/busy_read|busy_read latency boost
fq_codel|/proc/sys/net/core/default_qdisc|fq_codel latencia baja
100|/proc/sys/net/core/dev_weight|dev_weight
2|/proc/sys/net/core/dev_weight_rx_bias|rx bias
2|/proc/sys/net/core/dev_weight_tx_bias|tx bias
20|/proc/sys/net/core/max_skb_frags|max_skb_frags
256|/proc/sys/net/core/netdev_budget|budget latency
800|/proc/sys/net/core/netdev_budget_usecs|budget_usecs latency
512|/proc/sys/net/core/netdev_max_backlog|backlog reducido
0|/proc/sys/net/core/netdev_tstamp_prequeue|prequeue off
16777216|/proc/sys/net/core/wmem_max|wmem_max 16MB
16777216|/proc/sys/net/core/rmem_max|rmem_max 16MB
262144|/proc/sys/net/core/rmem_default|256KB
262144|/proc/sys/net/core/wmem_default|256KB
131072|/proc/sys/net/core/optmem_max|128KB
32768|/proc/sys/net/core/rps_sock_flow_entries|rps activado
2048|/proc/sys/net/core/somaxconn|somaxconn aumentado
1|/proc/sys/net/core/tstamp_allow_data|tstamp
EOF2

apply_param_set <<'EOF2'
0|/proc/sys/net/ipv4/tcp_ecn|ECN off latencia
1|/proc/sys/net/ipv4/tcp_sack|SACK on
1|/proc/sys/net/ipv4/tcp_fack|FACK on
1|/proc/sys/net/ipv4/tcp_window_scaling|window scaling
4096 87380 16777216|/proc/sys/net/ipv4/tcp_rmem|rmem 16MB
4096 87380 16777216|/proc/sys/net/ipv4/tcp_wmem|wmem 16MB
524288 1048576 2097152|/proc/sys/net/ipv4/tcp_mem|tcp_mem
1|/proc/sys/net/ipv4/tcp_no_metrics_save|no_metrics
3|/proc/sys/net/ipv4/tcp_fastopen|fastopen
2|/proc/sys/net/ipv4/tcp_retries1|retries1 reducido
6|/proc/sys/net/ipv4/tcp_retries2|retries2 reducido
262144|/proc/sys/net/ipv4/tcp_limit_output_bytes|256KB
1|/proc/sys/net/ipv4/tcp_orphan_retries|orphan reducido
4096|/proc/sys/net/ipv4/tcp_max_syn_backlog|syn backlog
32768|/proc/sys/net/ipv4/tcp_max_orphans|orphans
3|/proc/sys/net/ipv4/tcp_fin_timeout|fin_timeout agresivo
20|/proc/sys/net/ipv4/tcp_keepalive_time|keepalive 20s
3|/proc/sys/net/ipv4/tcp_keepalive_intvl|intvl 3s
3|/proc/sys/net/ipv4/tcp_keepalive_probes|probes
1|/proc/sys/net/ipv4/tcp_syncookies|syncookies
1|/proc/sys/net/ipv4/tcp_timestamps|timestamps
0|/proc/sys/net/ipv4/tcp_slow_start_after_idle|no slow start
1|/proc/sys/net/ipv4/tcp_low_latency|low_latency ON
1|/proc/sys/net/ipv4/tcp_mtu_probing|mtu probing
1|/proc/sys/net/ipv4/tcp_frto|frto
1|/proc/sys/net/ipv4/tcp_moderate_rcvbuf|moderate rcvbuf
1|/proc/sys/net/ipv4/tcp_early_retrans|early retrans
3|/proc/sys/net/ipv4/tcp_early_demux|early demux
1|/proc/sys/net/ipv4/udp_early_demux|udp early demux
512 65535|/proc/sys/net/ipv4/ip_local_port_range|puertos expandido
0 2147483647|/proc/sys/net/ipv4/ping_group_range|ping group
1|/proc/sys/net/ipv4/tcp_rfc1337|rfc1337
EOF2

# BBR dinámico
if [ -f /proc/sys/net/ipv4/tcp_available_congestion_control ]; then
    if grep -qw bbr2 /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null; then
        echo "bbr2" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
        echo "[PROFILE] gaming: bbr2" >> "$profile_aplicated"
    elif grep -qw bbr /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null; then
        echo "bbr" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
        echo "[PROFILE] gaming: bbr" >> "$profile_aplicated"
    else
        echo "cubic" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
        echo "[PROFILE] gaming: cubic fallback" >> "$profile_aplicated"
    fi
fi

# CAKE qdisc si disponible
if tc qdisc add dev lo root cake 2>/dev/null; then
    tc qdisc del dev lo root 2>/dev/null
    echo "cake" > /proc/sys/net/core/default_qdisc 2>/dev/null
    echo "[PROFILE] gaming: qdisc=cake" >> "$profile_aplicated"
fi


# ── WiFi Boost: extrae todo el internet del WiFi ──────────────────────────
_MODDIR_WB="${NEWMODPATH:-${MODDIR:-}}"
if [ -f "$_MODDIR_WB/net_profiles/wifi_boost.sh" ]; then
    . "$_MODDIR_WB/net_profiles/wifi_boost.sh"
fi
echo "[PROFILE] gaming done" >> "$profile_aplicated"
